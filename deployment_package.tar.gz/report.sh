#!/bin/bash
echo "# CANCAN KERN - IMPACT REPORT" > REPORT.md
echo "## Generated on: $(date)" >> REPORT.md
echo "---" >> REPORT.md
echo "### 1. Cumulative Statistics" >> REPORT.md
DEBT=$(grep -oP "penalty\":\K[0-9.]+" vault/digital_twin_log.json | awk '{sum+=$1} END {print sum}')
COUNT=$(grep -c "event" vault/digital_twin_log.json)
echo "* **Total Environmental Debt Identified:** \$${DEBT:-0}" >> REPORT.md
echo "* **Total Unique Audits Completed:** ${COUNT}" >> REPORT.md
echo "" >> REPORT.md
echo "### 2. Material Breakdown" >> REPORT.md
grep -oP "material\":\"\K[^\"]+" vault/digital_twin_log.json | sort | uniq -c | awk '{print "* " $2 ": " $1 " items"}' >> REPORT.md
echo "---" >> REPORT.md
echo "Report saved to REPORT.md. Ready for website upload."
