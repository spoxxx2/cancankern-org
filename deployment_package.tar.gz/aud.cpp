#include <iostream>
#include <fstream>
#include <string>
#include <sys/stat.h>

std::string get_env_var(std::string key) {
    std::ifstream env(".env");
    std::string line;
    while (std::getline(env, line)) {
        if (line.find(key + "=") == 0) return line.substr(key.length() + 1);
    }
    return "";
}

void deposit_to_zenodo() {
    std::string token = get_env_var("ZENODO_TOKEN");
    if (token.empty()) { std::cerr << "[ERR] No Token." << std::endl; return; }

    std::cout << "[STEP 1] Creating Deposition..." << std::endl;
    std::string metadata = "{\"metadata\":{\"title\":\"Cancan Kern Audit Engine\",\"upload_type\":\"software\",\"description\":\"Bakersfield Environmental Debt & BSFL Logic.\",\"creators\":[{\"name\":\"Cancan Kern\"}],\"license\":\"cc-by-4.0\"}}";
    
    // Create record and capture the ID (simplified for shell)
    std::string create_cmd = "curl -s -H 'Authorization: Bearer " + token + "' -H 'Content-Type: application/json' -X POST https://zenodo.org/api/deposit/depositions -d '" + metadata + "' > zenodo_res.json";
    system(create_cmd.c_str());

    // Extract ID using grep/sed (Termux friendly)
    std::string id_cmd = "grep -oP '\"id\":\\K[0-9]+' zenodo_res.json | head -1 > zenodo_id.txt";
    system(id_cmd.c_str());
    
    std::ifstream id_file("zenodo_id.txt");
    std::string dep_id;
    id_file >> dep_id;

    if (!dep_id.empty()) {
        std::cout << "[STEP 2] Uploading deployment_package.tar.gz to ID: " << dep_id << std::endl;
        std::string upload_cmd = "curl -s -H 'Authorization: Bearer " + token + "' --upload-file deployment_package.tar.gz 'https://zenodo.org/api/deposit/depositions/" + dep_id + "/files?filename=deployment_package.tar.gz'";
        system(upload_cmd.c_str());
        system("termux-tts-speak 'Scientific deposit complete. Your code and data are now immutable.'");
    }
}

int main(int argc, char* argv[]) {
    mkdir("data", 0777); mkdir("vault", 0777);
    std::string mode = (argc > 1) ? argv[1] : "";
    if (mode == "--zenodo") {
        deposit_to_zenodo();
    } else {
        std::ofstream log("vault/digital_twin_log.json", std::ios_base::app);
        log << "{\"event\":\"audit\",\"status\":\"locked\"}" << std::endl;
        std::cout << "--- AUDIT SECURED ---" << std::endl;
    }
    return 0;
}
